Per cambiare la lingua inserisci _lang e poi inserisci l'acronimo della tua lingua
To change the language, type _lang and than insert the acronym of your language
To change the language enter _lang and then enter the acronym of your language
Para cambiar el idioma ingrese _lang y luego ingrese el acr�nimo de su idioma